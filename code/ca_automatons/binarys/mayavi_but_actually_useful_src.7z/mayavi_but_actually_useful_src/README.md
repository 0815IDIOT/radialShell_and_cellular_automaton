# MAYAVI BUT ACTUALLY USEFUL
I made this visualisation because mayavi renders things in the wrong order, so it looks wrong depth-wise. And because we get a division by zero error when using the correct center...

## HOW TO BUILD:
To build a binary from the project, follow these steps:
* Install Godot Engine v3.x (not compatible with Godot 4!) ( https://godotengine.org/ )
* Open Godot, and Import the Project, then open it  
* Once it loaded, in the menubar click on "Editor" -> "Export Templates"  
* Install the latest version, close the window when it's done
* in the menubar click on Project -> Export  
* Select either Windows or Linux  
* Click "export project"  
* Select a file location and enter a file name for the binary  
* untick "export with debug information" below the filename entry field  
* click "save"  
  
That's all!
